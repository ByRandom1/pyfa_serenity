<!--

Submit a bug report bug report or feature request

Here you can inform pyfa developers of potential bugs or suggest features / improvements to the project. Please check
to make sure that the bug hasn't been reported or feature requested before submitting. If you have general questions
about the project and want to reach out to the developers personally, please check out out our [Slack]
(https://pyfainvite.azurewebsites.net/).

-->

## Bug Report


### Expected behavior:


### Actual behavior:


### Detailed steps to reproduce:


### Fits involved in EFT format (Edit > To Clipboard > EFT):


### Release or development git branch? Please note the release version or commit hash:


### Operating system and version (eg: Windows 10, OS X 10.9, OS X 10.11, Ubuntu 16.10):


### Other relevant information:

