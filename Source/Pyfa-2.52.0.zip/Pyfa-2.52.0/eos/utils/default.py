class DEFAULT:
    """Singleton class to signify default argument value."""
    pass
