# noinspection PyPackageRequirements
import wx.lib.newevent

ResistModeChanged, RESIST_MODE_CHANGED = wx.lib.newevent.NewEvent()
