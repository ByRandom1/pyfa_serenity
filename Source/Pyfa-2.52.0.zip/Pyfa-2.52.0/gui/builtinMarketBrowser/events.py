# noinspection PyPackageRequirements
import wx.lib.newevent


ItemSelected, ITEM_SELECTED = wx.lib.newevent.NewEvent()

RECENTLY_USED_MODULES = -2
